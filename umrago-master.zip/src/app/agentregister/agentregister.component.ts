import { Component, OnInit } from '@angular/core';
declare var $:any;
declare const M;

@Component({
  selector: 'app-agentregister',
  templateUrl: './agentregister.component.html',
  styleUrls: ['./agentregister.component.css']
})
export class AgentregisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.jquery_code();


  }
  jquery_code(){

    $(document).ready(function(){
      
    $('#textarea1').val('') ;
    M.textareaAutoResize($('#textarea1'));

   
    });

    $('select').formSelect();

  }
  
  
 
}